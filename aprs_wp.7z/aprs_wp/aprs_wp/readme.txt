// APRS-IS client for Windows Phone by Petri-Veikko Alaj�rvi (OH1GIU)
// Developed and tested (in WP emulator) with Windows Phone 7.1 (Mango) SDK
// THIS SOURCE CODE IS FREE
// You can freely use this source code in your own projects and applications released in the Windows Phone marketplace.
//
// When building/deploying for real device change gensets.TEST_MODE value to false
// Tnx to OH1KO & OH7LZB for help and advices !!