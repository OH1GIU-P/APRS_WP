﻿using System;
using System.Net;

namespace wpAPRS
{
    public class gpsutil
    {
        public string toAprsLat(double lat)
        {
            return toAprsLoc(lat, gensets.LOC_LAT, gensets.LOC_LAT_LEN);
        }

        public string toAprsLon(double lon)
        {
            return toAprsLoc(lon, gensets.LOC_LON, gensets.LOC_LON_LEN);
        }

        // Convert double decimal location to APRS (NMEA) type location

        private string toAprsLoc(double loc, string nsew, int len)
        {
            if (loc >= 0.0)
            {
                nsew = nsew.Substring(0, 1);
            }
            else
            {
                loc = loc * -1;
                nsew = nsew.Substring(1, 1);
            }

            loc += 0.00005;
            int locint = Convert.ToInt32(loc);

            double locdec = loc - locint;
            loc = (locint) * 100 + locdec * 60.0;

            string locstr = Convert.ToString(loc) + "0";
            int i = locstr.IndexOf(".");
            locstr = locstr.Substring(0, i + 3) + nsew;

            if (locstr.Length < len)
            {
                locstr = "0000".Substring(0, len - locstr.Length) + locstr;
            }
            return locstr;
        }

        public string fmtnum(double d)
        {
            d = Math.Floor(d + 0.5);
            string s = Convert.ToString(d);
            int l = s.Length;

            if (l >= 0 && l < 4 && d >= 0)
            {
                s = "000".Substring(0, 3 - l) + s;
            }
            else
            {
                s = "---";
            }
            return s;
        }

        public byte[] StringToAscii(string s)
        {
            byte[] retval = new byte[s.Length];
            for (int ix = 0; ix < s.Length; ++ix)
            {
                char ch = s[ix];
                if (ch <= 0x7f) retval[ix] = (byte)ch;
                else retval[ix] = (byte)'?';
            }
            return retval;
        }

    }
}
