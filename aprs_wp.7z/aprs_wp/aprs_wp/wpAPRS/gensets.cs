﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace wpAPRS
{
    public static class gensets
    {
        public const bool TEST_MODE = true; // when building for real device change gensets.TEST_MODE value to false
        public const double GEO_TIMEOUT = 2000; //ms
        public const string GEO_ERR_TIMEOUT = "GeoCoordinateWatcher timed out on start";
        public const int APRS_CONNECT_TIMEOUT = 30000; //ms
        public const int APRS_SEND_TIMEOUT = 30000; //ms

        public const string APRS_MSG_SEND_USER = "user ";
        public const string APRS_MSG_SEND_PASS = " pass ";
        public const string APRS_MSG_SEND_SW = " vers wpAPRS 1.0";

        public const string APRS_MSG_SEND_LOC = ">APRS,TCPIP*:!";

        public const string APRS_SERVER_CONN = "Connected to APRS-IS server";
        public const string APRS_SERVER_NO_CONN = "No connection";
        public const string APRS_SERVER_CONN_ERR_TIMEOUT = "Connection timeout error";
        public const string APRS_SERVER_SEND_ERR_TIMEOUT = "Send to APRS-IS server timeout";
        public const string APRS_NO_SETTINGS = "No APRS-IS settings found. Application merely shows GPS data";

        public const string SOCK_ERR = "Socket error: ";

        public const string APP_TITLE = "APRS";
        public const string APP_CAP = "wpAPRS";
        public const string APP_VERSION = "Version 1.0";
        public const string APP_COPYRIGHT = "(c) 2012 Petri-Veikko Alajärvi (OH1GIU)";
        public const string DEV_FW = "Firmware version ";
        public const string DEV_HW = "Hardware version ";
        public const string DEV_NAME = "Name: ";
        public const string DEV_MANU = "Manufacturer: ";
        public const string DEV_CLR = "CLR version ";
        public const string DEV_BUILD = " build ";
        public const string DEV_REV = " revision ";
        public const string LOC_LAT = "NS";
        public const string LOC_LON = "EW";
        public const int LOC_LAT_LEN = 8;
        public const int LOC_LON_LEN = 9;
        public const string LOC_SPEED = " m/s";
        public const string LOC_SPEED2 = " km/h ";
        public const string LOC_ALT = " m";
        public const string LOC_HACC = "Horiz. acc. ";
        public const string LOC_VACC = "Vert. acc. ";
        public const string LOC_ALT_TXT = "Alt. ";
        public const string LOC_COURSE = "°";
        public const string CONF_START = "Start";
        public const string CONF_STOP = "Stop";
        public const string ERR_FLD_MAND = "Mandatory field value is missing";
        public const string ERR_NO_TCP_PORT = "No TCP port number in APRS-IS server address";
        public const string ERR_TCP_PORT_NOT_NUMERIC = "TCP port is not numeric";
        public const string ERR_NO_ADDRESS = "Invalid APRS-IS server";
        public const string DATA_SAVED = "Configuration settings saved";

        public const int ISOSTR_DATA_ROWS = 8;
        public const double POLL_INT = 5;
    }
}
