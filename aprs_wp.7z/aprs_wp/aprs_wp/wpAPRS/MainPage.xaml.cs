﻿// APRS-IS client for Windows Phone by Petri-Veikko Alajärvi (OH1GIU), rf_frontend@hotmail.com, http://kotisivu.dnainternet.net/pa255/
// Developed and tested (in WP emulator) with Windows Phone 7.1 (Mango) SDK
// THIS SOURCE CODE IS FREE
// You can freely use this source code in your own projects and applications released in the Windows Phone marketplace.
//
// When building/deploying for real device change gensets.TEST_MODE value to false
// Tnx to OH1KO & OH7LZB for help and advices !!

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Info;
using System.Device.Location;
using System.Net.Sockets;
using System.Windows.Threading;
using System.Threading;

namespace wpAPRS
{
    public partial class MainPage : PhoneApplicationPage
    {
        private GeoCoordinateWatcher watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High);
        private double dLat = 0;
        private double dLon = 0;
        private double dCourse = Double.NaN;
        private double dSpeed = Double.NaN;
        private int iTcpPort;
        private bool bConnection = false;
        private bool bPos = false;
        Socket socketAPRS = null;
        static ManualResetEvent done = new ManualResetEvent(false);
        private string aprsMsg = string.Empty;
        private DispatcherTimer timer = new DispatcherTimer();
        private System.Text.StringBuilder sb = new System.Text.StringBuilder();
        private string sendData = string.Empty;

        private bool bSlider = false;
        private bool bIsAprsOn = false;
        private IsoStoHandler isoSto;
        private bool bStart = true;
        private string[] sAprs_data = new string[8] {"","","","","","","",""};

        private string aprsSym = ">";
        private gpsutil gutil = null;
        private string strLogin = string.Empty;
        private bool bShowLoginStr = true;
        private bool bSocketError = false;

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            DataContext = App.ViewModel;
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);

            ClearLocTexts();
            GetAboutInfo();
            bSlider = true;
            textBlockLocSpc.Text = gensets.APRS_SERVER_NO_CONN;
            watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
            this.timer.Tick += new EventHandler(timer_Tick);
            this.Loaded += new RoutedEventHandler(timer_Tick);
            gutil = new gpsutil();
        }

        // Load data for the ViewModel Items
        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (!App.ViewModel.IsDataLoaded)
            {
                App.ViewModel.LoadData();
            }

            if (bStart)
            {
                bStart = false;
                isoSto = new IsoStoHandler();

                // for testing in emulator
                // stores test values in isolated storage
                // when building for real device change gensets.TEST_MODE value to false
                if (gensets.TEST_MODE)
                {
                    sAprs_data[0] = "OH1xxx-7"; // callsign
                    sAprs_data[1] = "0000"; // passcode
                    sAprs_data[2] = "finland.aprs2.net:14580";
                    sAprs_data[3] = "windows phone test";
                    sAprs_data[4] = "1"; // polling interval in minutes
                    sAprs_data[5] = "finland.aprs2.net";
                    sAprs_data[6] = "14580";
                    sAprs_data[7] = aprsSym; // aprs symbol, http://wa8lmf.net/aprs/APRS_symbols.htm
                    isoSto.CreateDataFile(sAprs_data);
                }

                if (isoSto.ReadDataFile(out sAprs_data[0], out sAprs_data[1], out sAprs_data[2], out sAprs_data[3], out sAprs_data[4], out sAprs_data[5], out sAprs_data[6], out sAprs_data[7]))
                {
                    textBoxConfCallsign.Text = sAprs_data[0];
                    textBoxConfAPRSpasscode.Text = sAprs_data[1];
                    textBoxConfAPRS.Text = sAprs_data[2];
                    textBoxConfName.Text = sAprs_data[3].Trim();
                    double d = 0;
                    if (double.TryParse(sAprs_data[4], out d))
                    {
                        if (d > 0)
                        {
                            sliderConfPollingInt.Value = d;
                        }
                        else
                        {
                            sliderConfPollingInt.Value = gensets.POLL_INT;
                        }
                    }
                    else
                        sliderConfPollingInt.Value = gensets.POLL_INT;
                    Int32.TryParse(sAprs_data[6], out iTcpPort);
                }
            }
        }

        private void GetAboutInfo()
        {
            textBlockAboutCap.Text = gensets.APP_CAP;
            textBlockAboutVer.Text = gensets.APP_VERSION;
            textBlockAboutC.Text = gensets.APP_COPYRIGHT;
            textBlockAboutFirmware.Text = gensets.DEV_FW + DeviceStatus.DeviceFirmwareVersion;
            textBlockAboutHW.Text = gensets.DEV_HW + DeviceStatus.DeviceHardwareVersion;
            textBlockAboutDevName.Text = gensets.DEV_NAME + DeviceStatus.DeviceName;
            textBlockAboutManu.Text = gensets.DEV_MANU + DeviceStatus.DeviceManufacturer;
            textBlockAboutOSversion.Text = Environment.OSVersion.ToString();
            textBlockAboutCLR.Text = gensets.DEV_CLR + Environment.Version.Major.ToString() + "." + Environment.Version.Minor.ToString() + 
            gensets.DEV_REV + Environment.Version.Revision.ToString() + gensets.DEV_BUILD + Environment.Version.Build.ToString();
        }

        private void ClearLocTexts()
        {
            textBlockLocLat.Text = "";
            textBlockLocLon.Text = "";
            textBlockLocSpeed.Text = "";
            textBlockLocCourse.Text = "";
            textBlockLocAlt.Text = "";
            textBlockLocTs.Text = "";
            textBlockLocHacc.Text = "";
            textBlockLocSpc.Text = " ";
            textBlockLocSpc2.Text = " ";
        }

        private void textBoxConfCallsign_TextChanged(object sender, TextChangedEventArgs e)
        {
            int cursorLocation = textBoxConfCallsign.SelectionStart;
            textBoxConfCallsign.Text = textBoxConfCallsign.Text.ToUpper();
            textBoxConfCallsign.SelectionStart = cursorLocation;
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (bSlider)
                textBlockConfPollingInt.Text = "Polling interval (" + Math.Round(e.NewValue).ToString() + " minutes)";
        }

        private void buttonConfSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxConfCallsign.Text.Trim()))
            {
                MessageBox.Show(gensets.ERR_FLD_MAND);
                textBoxConfCallsign.Focus();
                return;
            }
            if (string.IsNullOrEmpty(textBoxConfAPRSpasscode.Text.Trim()))
            {
                MessageBox.Show(gensets.ERR_FLD_MAND);
                textBoxConfAPRSpasscode.Focus();
                return;
            }
            if (string.IsNullOrEmpty(textBoxConfAPRS.Text.Trim()))
            {
                MessageBox.Show(gensets.ERR_FLD_MAND);
                textBoxConfAPRS.Focus();
                return;
            }

            string sTcpPort = string.Empty;
            string sAddress = string.Empty;
            string sAtcp = textBoxConfAPRS.Text.Trim();
            int p = sAtcp.IndexOf(":");
            if (p > 0)
            {
                int l = sAtcp.Length;
                if (l > p)
                {
                    sTcpPort = sAtcp.Substring(p + 1, l - p - 1);
                    sAddress = sAtcp.Substring(0, p);
                }
            }

            if (string.IsNullOrEmpty(sTcpPort))
            {
                MessageBox.Show(gensets.ERR_NO_TCP_PORT);
                textBoxConfAPRS.Focus();
                return;
            }

            int iTempPort;
            if (Int32.TryParse(sTcpPort, out iTempPort) == false)
            {
                MessageBox.Show(gensets.ERR_TCP_PORT_NOT_NUMERIC);
                textBoxConfAPRS.Focus();
                return;
            }

            if (string.IsNullOrEmpty(sAddress))
            {
                MessageBox.Show(gensets.ERR_NO_ADDRESS);
                textBoxConfAPRS.Focus();
                return;
            }

            iTcpPort = iTempPort;
            sAprs_data[0] = textBoxConfCallsign.Text.Trim();
            sAprs_data[1] = textBoxConfAPRSpasscode.Text.Trim();
            sAprs_data[2] = textBoxConfAPRS.Text.Trim();
            if (string.IsNullOrEmpty(textBoxConfName.Text.Trim()) == false)
                sAprs_data[3] = textBoxConfName.Text.Trim();
            else
                sAprs_data[3] = " ";
            sAprs_data[4] = Math.Round(sliderConfPollingInt.Value).ToString();
            sAprs_data[5] = sAddress;
            sAprs_data[6] = sTcpPort;
            sAprs_data[7] = aprsSym;

            isoSto.CreateDataFile(sAprs_data);
            MessageBox.Show(gensets.DATA_SAVED);
        }

        private void buttonLocStartStop_Click(object sender, RoutedEventArgs e)
        {
            ClearLocTexts();
            pivotMain.Title = gensets.APP_TITLE;

            bool bSettingsOk = true;
            if (bIsAprsOn == false)
            {
                if (string.IsNullOrEmpty(sAprs_data[0]) || string.IsNullOrEmpty(sAprs_data[1]) || string.IsNullOrEmpty(sAprs_data[4]) || string.IsNullOrEmpty(sAprs_data[5]) || string.IsNullOrEmpty(sAprs_data[6]))
                {
                    bSettingsOk = false;
                    MessageBox.Show(gensets.APRS_NO_SETTINGS);
                }
            }

            CloseConnection();
            StopTimer();
            if (bIsAprsOn)
            {
                watcher.Stop();
                InitGpsDs();
                bPos = false;
                bIsAprsOn = false;
                buttonLocStartStop.Content = gensets.CONF_START;
            }
            else
            {
                bPos = false;
                InitGpsDs();
                if (watcher.TryStart(false, TimeSpan.FromMilliseconds(gensets.GEO_TIMEOUT)) == true)
                {
                    bIsAprsOn = true;
                    buttonLocStartStop.Content = gensets.CONF_STOP;
                    if (bSettingsOk == true)
                    {
                        sb.Clear();
                        sb.Append(gensets.APRS_MSG_SEND_USER);
                        sb.Append(sAprs_data[0]);
                        sb.Append(gensets.APRS_MSG_SEND_PASS);
                        sb.Append(sAprs_data[1]);
                        sb.Append(gensets.APRS_MSG_SEND_SW);
                        sb.Append(Environment.NewLine);
                        strLogin = sb.ToString();
                        StartTimer();
                        //CreateConnection();
                        //if (bConnection == true)
                        //{
                        //    textBlockLocSpc.Text = gensets.APRS_SERVER_CONN;
                        //    sb.Clear();
                        //    sb.Append(gensets.APRS_MSG_SEND_USER);
                        //    sb.Append(sAprs_data[0]);
                        //    sb.Append(gensets.APRS_MSG_SEND_PASS);
                        //    sb.Append(sAprs_data[1]);
                        //    sb.Append(gensets.APRS_MSG_SEND_SW);
                        //    sb.Append(Environment.NewLine);
                        //    sendData = sb.ToString();

                        //    if (AprsSend(sendData) == true)
                        //    {
                        //        textBlockLocSpc2.Text = sendData;
                        //        StartTimer();
                        //    }
                        //    else
                        //    {
                        //        bConnection = false;
                        //        textBlockLocSpc2.Text = gensets.APRS_SERVER_SEND_ERR_TIMEOUT;
                        //    }
                        //}
                    }
                }
                else
                {
                    MessageBox.Show(gensets.GEO_ERR_TIMEOUT);
                }
            }
        }

        private void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            dLat = e.Position.Location.Latitude;
            dLon = e.Position.Location.Longitude;
            dSpeed = e.Position.Location.Speed;
            dCourse = e.Position.Location.Course;

            //dSpeed = 9;
            //dCourse = 9;

            bPos = true;
            textBlockLocLat.Text = dLat.ToString();
            textBlockLocLon.Text = dLon.ToString();
            textBlockLocSpeed.Text = Math.Round(dSpeed, 2).ToString() + gensets.LOC_SPEED + "    " + Math.Round(dSpeed * 3.6, 2).ToString() + gensets.LOC_SPEED2;
            textBlockLocAlt.Text = gensets.LOC_ALT_TXT + Math.Round(e.Position.Location.Altitude).ToString() + gensets.LOC_ALT + "  " + gensets.LOC_VACC + Math.Round(e.Position.Location.VerticalAccuracy).ToString() + gensets.LOC_ALT;
            textBlockLocCourse.Text = dCourse.ToString() + gensets.LOC_COURSE;
            textBlockLocHacc.Text = gensets.LOC_HACC + Math.Round(e.Position.Location.HorizontalAccuracy).ToString() + gensets.LOC_ALT;
            textBlockLocTs.Text = e.Position.Timestamp.ToString("dd.MM.yyyy hh:mm:ss");
        }

        private void CreateConnection()
        {
            bool bSockConn = true;

            CloseConnection();

            socketAPRS = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socketAPRS.NoDelay = true;
            
            SocketAsyncEventArgs socketEventArg = new SocketAsyncEventArgs();
            socketEventArg.RemoteEndPoint = new DnsEndPoint(sAprs_data[5], iTcpPort);
            socketEventArg.Completed += new
            EventHandler<SocketAsyncEventArgs>(delegate(object o, SocketAsyncEventArgs e)
            {
                if (e.SocketError != SocketError.Success)
                {
                    bSockConn = false;
                    textBlockLocSpc2.Text = gensets.SOCK_ERR + e.SocketError.ToString();
                }
                done.Set();
            });
            done.Reset();
            socketAPRS.ConnectAsync(socketEventArg);
            if (done.WaitOne(gensets.APRS_CONNECT_TIMEOUT))
            {
                bConnection = true;
            }
            else
            {
                bSockConn = false;
                textBlockLocSpc.Text = gensets.APRS_SERVER_CONN_ERR_TIMEOUT;
            }
            if (bSockConn == false)
                bConnection = false;
        }

        private void InitGpsDs()
        {
            dCourse = Double.NaN;
            dSpeed = Double.NaN;
            dLat = 0;
            dLon = 0;
        }

        private void CloseConnection()
        {
            bConnection = false;
            if (socketAPRS != null)
            {
                socketAPRS.Close();
                socketAPRS = null;
            }
        }

        private void StartTimer()
        {
            StopTimer();
            bShowLoginStr = true;
            timer.Interval = TimeSpan.FromSeconds(double.Parse(sAprs_data[4]) * 60);
            timer.Start();
        }

        private void StopTimer()
        {
            timer.Stop();
        }

        void timer_Tick(Object sender, EventArgs args)
        {
            if (bPos == true)
            {
                CreateConnection();
                if (bConnection == true)
                {
                    textBlockLocSpc.Text = gensets.APRS_SERVER_CONN;

                    if (AprsSend(strLogin) == true)
                    {
                        if (bShowLoginStr)
                        {
                            bShowLoginStr = false;
                            pivotMain.Title = strLogin.Replace(Environment.NewLine, "");
                        }
                    }
                    else
                    {
                        bConnection = false;
                        if (bSocketError == false)
                        {
                            textBlockLocSpc2.Text = gensets.APRS_SERVER_SEND_ERR_TIMEOUT;
                        }
                    }
                }

                if (bConnection == true)
                {
                    sb.Clear();
                    sb.Append(sAprs_data[0]);
                    sb.Append(gensets.APRS_MSG_SEND_LOC);
                    sb.Append(gutil.toAprsLat(dLat));
                    sb.Append("/");
                    sb.Append(gutil.toAprsLon(dLon));
                    sb.Append(sAprs_data[7]);
                    if (dSpeed.Equals(Double.NaN) == false && dCourse.Equals(Double.NaN) == false)
                    {
                        sb.Append(gutil.fmtnum(dCourse));
                        sb.Append("/");
                        sb.Append(gutil.fmtnum((dSpeed * 3.6) / 1.852));
                    }
                    sb.Append(sAprs_data[3]);
                    sb.Append(Environment.NewLine);
                    sendData = sb.ToString();

                    if (AprsSend(sendData) == true)
                    {
                        textBlockLocSpc2.Text = sendData.Replace(Environment.NewLine, "");
                    }
                    else
                    {
                        if (bSocketError == false)
                        {
                            textBlockLocSpc2.Text = gensets.APRS_SERVER_SEND_ERR_TIMEOUT;
                        }
                    }
                }
                CloseConnection();
            }
        }

        private bool AprsSend(string strToAprs)
        {
            textBlockLocSpc2.Text = " ";
            bSocketError = false;
            if (socketAPRS != null)
            {
                SocketAsyncEventArgs socketEventArg = new SocketAsyncEventArgs();
                socketEventArg.RemoteEndPoint = socketAPRS.RemoteEndPoint;
                socketEventArg.UserToken = null;

                socketEventArg.Completed += new
                EventHandler<SocketAsyncEventArgs>(delegate(object o, SocketAsyncEventArgs e)
                {
                    if (e.SocketError != SocketError.Success)
                    {
                        bSocketError = true;
                        textBlockLocSpc2.Text = gensets.SOCK_ERR + e.SocketError.ToString();
                    }
                    done.Set();
                });

                byte[] byteArr = gutil.StringToAscii(strToAprs);
                socketEventArg.SetBuffer(byteArr, 0, byteArr.Length);
                done.Reset();
                socketAPRS.SendAsync(socketEventArg);

                return done.WaitOne(gensets.APRS_SEND_TIMEOUT);
            }
            return false;
        }

    }
}