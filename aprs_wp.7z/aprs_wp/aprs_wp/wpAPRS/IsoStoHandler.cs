﻿using System;
using System.Net;
using System.IO;
using System.IO.IsolatedStorage;
using System.Windows.Resources;
using System.Windows;

namespace wpAPRS
{
    public class IsoStoHandler
    {
        private const string FileName = "wpAPRS_settings.txt";
        private const string FolderName = "wpAPRS_app_data";
        private string FilePath = System.IO.Path.Combine(FolderName, FileName);

        private string[] isoStrData = new string[gensets.ISOSTR_DATA_ROWS];

        public void CreateDataFile(string[] strData)
        {
            CreateNewFile(FilePath, strData);
        }

        public bool ReadDataFile(out string s1, out string s2, out string s3, out string s4, out string s5, out string s6, out string s7, out string s8)
        {
            bool b = false;
            b = ReadFile(FilePath);
            s1 = isoStrData[0];
            s2 = isoStrData[1];
            s3 = isoStrData[2];
            s4 = isoStrData[3];
            s5 = isoStrData[4];
            s6 = isoStrData[5];
            s7 = isoStrData[6];
            s8 = isoStrData[7];
            return b;
        }

        public void removeIsoStr()
        {
            using (IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForApplication())
            {
                store.Remove();
            }
        }

        private void CreateNewFile(string filePath, string[] fdata)
        {
            //StreamResourceInfo streamResourceInfo = Application.GetResourceStream(new Uri(filePath, UriKind.Relative));

            using (IsolatedStorageFile myIsolatedStorage = IsolatedStorageFile.GetUserStoreForApplication())
            {
                string directoryName = System.IO.Path.GetDirectoryName(filePath);
                if (!string.IsNullOrEmpty(directoryName) && !myIsolatedStorage.DirectoryExists(directoryName))
                {
                    myIsolatedStorage.CreateDirectory(directoryName);
                }

                if (myIsolatedStorage.FileExists(filePath))
                {
                    myIsolatedStorage.DeleteFile(filePath);
                }

                using (IsolatedStorageFileStream fileStream = myIsolatedStorage.OpenFile(filePath, FileMode.Create, FileAccess.Write))
                {
                    using (StreamWriter writer = new StreamWriter(fileStream))
                    {
                        for (int i = 0; i < gensets.ISOSTR_DATA_ROWS; i++)
                        {
                            writer.WriteLine(fdata[i]);
                        }
                    }
                }
            }
        }

        private bool ReadFile(string filePath)
        {
            int i;
            for (i = 0; i < gensets.ISOSTR_DATA_ROWS; i++)
            {
                isoStrData[i] = string.Empty;
            }
            bool b = false;
            using (IsolatedStorageFile myIsolatedStorage = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (myIsolatedStorage.FileExists(filePath))
                {
                    using (IsolatedStorageFileStream fileStream = myIsolatedStorage.OpenFile(filePath, FileMode.Open, FileAccess.Read))
                    {
                        using (StreamReader reader = new StreamReader(fileStream))
                        {
                            for (i = 0; i < gensets.ISOSTR_DATA_ROWS; i++)
                            {
                                isoStrData[i] = reader.ReadLine();
                            }
                            b = true;
                        }
                    }
                }
                //else
                //{
                //    MessageBox.Show(FilePath + " " + GenSets.ERR_FILE_NOT_FOUND);
                //}
            }
            return b;
        }

    }
}
